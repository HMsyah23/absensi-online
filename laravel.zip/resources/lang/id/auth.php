<?php
return [
    'failed'   => 'Identitas tersebut tidak cocok dengan data kami.',
    'throttle' => 'Terlalu banyak usaha masuk. Silahkan coba lagi dalam :seconds detik.',
];
