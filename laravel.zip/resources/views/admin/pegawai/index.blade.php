<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="icon" href="{{ asset('app/icons/favicon.ico') }}">
    <meta name="theme-color" content="#8CC152">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <title>Absensi Online | Dashboard Admin</title>
    <link rel="stylesheet" type="text/css" href="{{ asset('styles/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('styles/style.css') }}">
    <link
        href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i|Source+Sans+Pro:300,300i,400,400i,600,600i,700,700i,900,900i&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('fonts/css/fontawesome-all.min.css') }}">
    <link rel="manifest" href="{{ asset('manifest.json') }}" data-pwa-version="set_in_manifest_and_pwa_js">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('app/icons/icon-192x192.png') }}">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css">
</head>

<body class="theme-light" data-highlight="highlight-red" data-gradient="body-default">

    <div id="preloader">
        <div class="spinner-border color-highlight" role="status"></div>
    </div>

    <div id="page">

        <div class="header header-fixed header-logo-center">
            <a href="#" class="header-title">Dashboard Admin</a>
            <a href="#" data-back-button class="header-icon header-icon-1"><i class="fas fa-arrow-left"></i></a>
            <a href="#" data-toggle-theme class="header-icon header-icon-4"><i class="fas fa-lightbulb"></i></a>
        </div>

        <div id="footer-bar" class="footer-bar-1">
            <a href="{{ route('admin.dashboard') }}"><i class="fa fa-home"></i><span>Dashboard</span></a>
            <a href="{{ route('admin.laporan') }}"><i class="fa fa-file-pdf"></i><span>Laporan</span></a>
            <a href="{{ route('admin.pegawais') }}" class="active-nav"><i class="fa fa-users"></i><span>Data
                    Pegawai</span></a>
            <a href="{{ route('admin.pengaturan') }}"><i class="fa fa-cog"></i><span>Pengaturan</span></a>
            <a href="{{ route('admin.logout') }}"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
        </div>

        <div class="page-content header-clear-medium">

            <div class="card card-style">
                <div class="content mb-2">
                    <h3>Daftar Pegawai</h3>
                    <p>
                        Daftar Pegawai Dinas Kependudukan, Pemberdayaan Perempuaan dan Perlindungan Anak
                    </p>
                    <table id="myTable" class="table table-borderless text-center rounded-sm shadow-l"
                        style="overflow: hidden;">
                        <thead>
                            <tr class="bg-gray-dark">
                                <th scope="col" class="color-white">No</th>
                                <th scope="col" class="color-white">NIP/ID</th>
                                <th scope="col" class="color-white">Nama</th>
                                <th scope="col" class="color-white">Status</th>
                                <th scope="col" class="color-white">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- End of Page Content-->
        <!-- All Menus, Action Sheets, Modals, Notifications, Toasts, Snackbars get Placed outside the <div class="page-content"> -->
        <div id="menu-detail" class="menu menu-box-modal menu-box-detached rounded-m" data-menu-height="480">
            <div class="menu-title">
                <h1>Detail Laporan</h1><a href="#" class="close-menu"><i class="fa fa-times"></i></a>
            </div>
            <div class="divider divider-margins mb-1 mt-3"></div>
            <div class="content">
                <div class="row mb-0">
                    <div class="col-3">
                        <img id="fotoPegawai" src="images/pictures/faces/1s.png" width="80" class="rounded-xl">
                    </div>
                    <div class="col-9 ps-4">
                        <div class="d-flex">
                            <div>
                                <p class="font-700 color-theme">Nama</p>
                            </div>
                            <div class="ms-auto" id="namaPegawai">
                                <p>-</p>
                            </div>
                        </div>
                        <div class="d-flex">
                            <div>
                                <p class="font-700 color-theme">NIP/ID</p>
                            </div>
                            <div class="ms-auto" id="nipId">
                                <p>-</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="divider mt-3 mb-3"></div>
                <div class="row mb-0">
                    <div class="col-3">
                        <h4 class="font-14">Bidang</h4>
                    </div>
                    <div class="col-9">
                        <h4 class="font-14 text-end" id="bidangPegawai">-</h4>
                    </div>
                    <div class="col-4">
                        <h4 class="font-14">Sub Bidang</h4>
                    </div>
                    <div class="col-8">
                        <h4 class="font-14 text-end" id="subBidangPegawai">-</h4>
                    </div>
                    <div class="divider divider-margins w-100 mt-2 mb-2"></div>
                    <div class="col-6">
                        <h4 class="font-14 mt-1">Golongan</h4>
                    </div>
                    <div class="col-6">
                        <h4 class="font-14 text-end mt-1" id="golonganPegawai">-</h4>
                    </div>
                    <div class="divider divider-margins w-100 mt-2 mb-2"></div>
                    <div class="col-6">
                        <h4 class="font-14 mt-1">Pangkat</h4>
                    </div>
                    <div class="col-6">
                        <h4 class="font-14 text-end mt-1" id="pangkatPegawai">-</h4>
                    </div>
                    <div class="divider divider-margins w-100 mt-2 mb-2"></div>
                    <div class="col-3">
                        <h4 class="font-14 mt-1">Jabatan</h4>
                    </div>
                    <div class="col-9">
                        <h4 class="font-14 text-end mt-1" id="jabatanPegawai">-</h4>
                    </div>
                    <div class="divider divider-margins w-100 mt-2 mb-2"></div>
                </div>
            </div>
        </div>

        <div id="menu-settings" class="menu menu-box-bottom menu-box-detached">
            <div class="menu-title mt-0 pt-0">
                <h1>Settings</h1>
                <p class="color-highlight">Flexible and Easy to Use</p><a href="#" class="close-menu"><i
                        class="fa fa-times"></i></a>
            </div>
            <div class="divider divider-margins mb-n2"></div>
            <div class="content">
                <div class="list-group list-custom-small">
                    <a href="#" data-toggle-theme data-trigger-switch="switch-dark-mode" class="pb-2 ms-n1">
                        <i class="fa font-12 fa-moon rounded-s bg-highlight color-white me-3"></i>
                        <span>Dark Mode</span>
                        <div class="custom-control scale-switch ios-switch">
                            <input data-toggle-theme type="checkbox" class="ios-input" id="switch-dark-mode">
                            <label class="custom-control-label" for="switch-dark-mode"></label>
                        </div>
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>
                <div class="list-group list-custom-large">
                    <a data-menu="menu-highlights" href="#">
                        <i class="fa font-14 fa-tint bg-green-dark rounded-s"></i>
                        <span>Page Highlight</span>
                        <strong>16 Colors Highlights Included</strong>
                        <span class="badge bg-highlight color-white">HOT</span>
                        <i class="fa fa-angle-right"></i>
                    </a>
                    <a data-menu="menu-backgrounds" href="#" class="border-0">
                        <i class="fa font-14 fa-cog bg-blue-dark rounded-s"></i>
                        <span>Background Color</span>
                        <strong>10 Page Gradients Included</strong>
                        <span class="badge bg-highlight color-white">NEW</span>
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- Menu Settings Highlights-->
        <div id="menu-highlights" class="menu menu-box-bottom menu-box-detached">
            <div class="menu-title">
                <h1>Highlights</h1>
                <p class="color-highlight">Any Element can have a Highlight Color</p><a href="#"
                    class="close-menu"><i class="fa fa-times"></i></a>
            </div>
            <div class="divider divider-margins mb-n2"></div>
            <div class="content">
                <div class="highlight-changer">
                    <a href="#" data-change-highlight="blue"><i class="fa fa-circle color-blue-dark"></i><span
                            class="color-blue-light">Default</span></a>
                    <a href="#" data-change-highlight="red"><i class="fa fa-circle color-red-dark"></i><span
                            class="color-red-light">Red</span></a>
                    <a href="#" data-change-highlight="orange"><i class="fa fa-circle color-orange-dark"></i><span
                            class="color-orange-light">Orange</span></a>
                    <a href="#" data-change-highlight="pink2"><i class="fa fa-circle color-pink2-dark"></i><span
                            class="color-pink-dark">Pink</span></a>
                    <a href="#" data-change-highlight="magenta"><i class="fa fa-circle color-magenta-dark"></i><span
                            class="color-magenta-light">Purple</span></a>
                    <a href="#" data-change-highlight="aqua"><i class="fa fa-circle color-aqua-dark"></i><span
                            class="color-aqua-light">Aqua</span></a>
                    <a href="#" data-change-highlight="teal"><i class="fa fa-circle color-teal-dark"></i><span
                            class="color-teal-light">Teal</span></a>
                    <a href="#" data-change-highlight="mint"><i class="fa fa-circle color-mint-dark"></i><span
                            class="color-mint-light">Mint</span></a>
                    <a href="#" data-change-highlight="green"><i class="fa fa-circle color-green-light"></i><span
                            class="color-green-light">Green</span></a>
                    <a href="#" data-change-highlight="grass"><i class="fa fa-circle color-green-dark"></i><span
                            class="color-green-dark">Grass</span></a>
                    <a href="#" data-change-highlight="sunny"><i class="fa fa-circle color-yellow-light"></i><span
                            class="color-yellow-light">Sunny</span></a>
                    <a href="#" data-change-highlight="yellow"><i class="fa fa-circle color-yellow-dark"></i><span
                            class="color-yellow-light">Goldish</span></a>
                    <a href="#" data-change-highlight="brown"><i class="fa fa-circle color-brown-dark"></i><span
                            class="color-brown-light">Wood</span></a>
                    <a href="#" data-change-highlight="night"><i class="fa fa-circle color-dark-dark"></i><span
                            class="color-dark-light">Night</span></a>
                    <a href="#" data-change-highlight="dark"><i class="fa fa-circle color-dark-light"></i><span
                            class="color-dark-light">Dark</span></a>
                    <div class="clearfix"></div>
                </div>
                <a href="#" data-menu="menu-settings"
                    class="mb-3 btn btn-full btn-m rounded-sm bg-highlight shadow-xl text-uppercase font-900 mt-4">Back
                    to Settings</a>
            </div>
        </div>
        <!-- Menu Settings Backgrounds-->
        <div id="menu-backgrounds" class="menu menu-box-bottom menu-box-detached">
            <div class="menu-title">
                <h1>Backgrounds</h1>
                <p class="color-highlight">Change Page Color Behind Content Boxes</p><a href="#"
                    class="close-menu"><i class="fa fa-times"></i></a>
            </div>
            <div class="divider divider-margins mb-n2"></div>
            <div class="content">
                <div class="background-changer">
                    <a href="#" data-change-background="default"><i class="bg-theme"></i><span
                            class="color-dark-dark">Default</span></a>
                    <a href="#" data-change-background="plum"><i class="body-plum"></i><span
                            class="color-plum-dark">Plum</span></a>
                    <a href="#" data-change-background="magenta"><i class="body-magenta"></i><span
                            class="color-dark-dark">Magenta</span></a>
                    <a href="#" data-change-background="dark"><i class="body-dark"></i><span
                            class="color-dark-dark">Dark</span></a>
                    <a href="#" data-change-background="violet"><i class="body-violet"></i><span
                            class="color-violet-dark">Violet</span></a>
                    <a href="#" data-change-background="red"><i class="body-red"></i><span
                            class="color-red-dark">Red</span></a>
                    <a href="#" data-change-background="green"><i class="body-green"></i><span
                            class="color-green-dark">Green</span></a>
                    <a href="#" data-change-background="sky"><i class="body-sky"></i><span
                            class="color-sky-dark">Sky</span></a>
                    <a href="#" data-change-background="orange"><i class="body-orange"></i><span
                            class="color-orange-dark">Orange</span></a>
                    <a href="#" data-change-background="yellow"><i class="body-yellow"></i><span
                            class="color-yellow-dark">Yellow</span></a>
                    <div class="clearfix"></div>
                </div>
                <a href="#" data-menu="menu-settings"
                    class="mb-3 btn btn-full btn-m rounded-sm bg-highlight shadow-xl text-uppercase font-900 mt-4">Back
                    to Settings</a>
            </div>
        </div>
        <!-- Menu Share -->
        <div id="menu-share" class="menu menu-box-bottom menu-box-detached">
            <div class="menu-title mt-n1">
                <h1>Share the Love</h1>
                <p class="color-highlight">Just Tap the Social Icon. We'll add the Link</p><a href="#"
                    class="close-menu"><i class="fa fa-times"></i></a>
            </div>
            <div class="content mb-0">
                <div class="divider mb-0"></div>
                <div class="list-group list-custom-small list-icon-0">
                    <a href="auto_generated" class="shareToFacebook external-link">
                        <i class="font-18 fab fa-facebook-square color-facebook"></i>
                        <span class="font-13">Facebook</span>
                        <i class="fa fa-angle-right"></i>
                    </a>
                    <a href="auto_generated" class="shareToTwitter external-link">
                        <i class="font-18 fab fa-twitter-square color-twitter"></i>
                        <span class="font-13">Twitter</span>
                        <i class="fa fa-angle-right"></i>
                    </a>
                    <a href="auto_generated" class="shareToLinkedIn external-link">
                        <i class="font-18 fab fa-linkedin color-linkedin"></i>
                        <span class="font-13">LinkedIn</span>
                        <i class="fa fa-angle-right"></i>
                    </a>
                    <a href="auto_generated" class="shareToWhatsApp external-link">
                        <i class="font-18 fab fa-whatsapp-square color-whatsapp"></i>
                        <span class="font-13">WhatsApp</span>
                        <i class="fa fa-angle-right"></i>
                    </a>
                    <a href="auto_generated" class="shareToMail external-link border-0">
                        <i class="font-18 fa fa-envelope-square color-mail"></i>
                        <span class="font-13">Email</span>
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="{{ asset('scripts/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('scripts/custom.js') }}"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        let token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        $(document).ready(function() {
            $('#myTable').DataTable({
                "ajax": "http://localhost:8000/api/pegawais",
                "columns": [{
                        "data": "id",
                        render: function(data, type, row, meta) {
                            return meta.row + meta.settings._iDisplayStart + 1;
                        }
                    },
                    {
                        "data": "nip"
                    },
                    {
                        "data": "nama_lengkap"
                    },
                    {
                        "data": "pns",
                        render: function(data, type, row, meta) {
                            if (data == 1) {
                                return 'PNS';
                            } else {
                                return 'PTT';
                            }
                        }
                    },
                    {
                        "data": "nip",
                        render: function(data, type, row, meta) {
                            return type === 'display' ? `
                            <a href="#" onclick="showModal('${data}')" class="me-3 mb-3 icon icon-s rounded-sm bg-facebook"><i class="fas fa-eye"></i></a>
                            <a href="pegawai/${data}/edit" class="me-3 mb-3 icon icon-s rounded-sm bg-green-dark"><i class="fas fa-edit"></i></a>
                            <a href="#" onclick="hapus('${data}')" class="me-3 mb-3 icon icon-s rounded-sm bg-pinterest"><i class="fas fa-trash"></i></a>
                        ` :
                                data;
                        }
                    },
                ],
                "order": [
                    [0, "asc"]
                ],
                "paging": true,
            });
        });

        function showModal(id) {
                const url = `{{ url('/api/pegawais/${id}') }}`;
                fetch(url)
                    .then((response) => {
                        return response.json();
                    })
                    .then((data) => {
                        if (data.data.photo !== null) {
                            document.getElementById('fotoPegawai').src = data.data.photo;
                        } else {
                            document.getElementById('fotoPegawai').src = 'https://via.placeholder.com/50';
                        }

                        document.getElementById('namaPegawai').innerHTML = data.data.nama_lengkap;
                        document.getElementById('nipId').innerHTML = data.data.nip;
                        document.getElementById('bidangPegawai').innerHTML = data.data.bidang.nama;
                        if (data.data.sub_bidang !== null) {
                            document.getElementById('subBidangPegawai').innerHTML = data.data.sub_bidang.nama;
                        } else {
                            document.getElementById('subBidangPegawai').innerHTML = `-`;
                        }

                        if (data.data.jabatan !== null) {
                            document.getElementById('jabatanPegawai').innerHTML = data.data.jabatan;
                        } else {
                            document.getElementById('jabatanPegawai').innerHTML = `-`;

                        }

                        if (data.data.golongan !== null) {
                            document.getElementById('golonganPegawai').innerHTML =
                                `${data.data.golongan.golongan}.${data.data.golongan.ruang}`;
                            document.getElementById('pangkatPegawai').innerHTML =
                                `${data.data.golongan.pangkat}`;
                        } else {
                            document.getElementById('golonganPegawai').innerHTML = `-`;
                            document.getElementById('pangkatPegawai').innerHTML = `-`;
                        }

                    })
                document.getElementById('menu-detail').classList.add('menu-active');
                document.getElementsByClassName('menu-hider')[0].classList.add('menu-active');
            }

            function hapus(id) {
                const url = `{{ url('/api/pegawais/${id}') }}`;
                fetch(url, {
                        headers: {
                            "Content-Type": "application/json",
                            "Accept": "application/json, text-plain, */*",
                            "X-Requested-With": "XMLHttpRequest",
                            "X-CSRF-TOKEN": token
                        },
                        method: 'DELETE',
                        credentials: "same-origin",
                        body: JSON.stringify({
                            id: id
                        })
                    })
                    .then((response) => response.json())
                    .then((json) => {
                        $('#myTable').DataTable().ajax.reload();
                    })
                    .catch(function(error) {
                        console.log(error);
                    });
            }
    </script>
</body>
