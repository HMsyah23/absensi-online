<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{

    public function index(){
        if(Auth::check()){
            return view('pegawai.index');
        }
        return redirect("login")->withSuccess('You are not allowed to access');
    }

    public function history(){
        if(Auth::check()){
            return view('pegawai.history',);
        }
        return redirect("login")->withSuccess('You are not allowed to access');
    }

    public function show($user)
    {
        $data = User::with('pegawai')->where('id',$user)->first();
        return response()->json(['data' => $data], 200);
    }

    public function list(){
        return view('pegawai.absen');
    }
}
