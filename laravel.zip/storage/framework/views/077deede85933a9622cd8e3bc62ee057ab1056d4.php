<!DOCTYPE HTML>
<html lang="en">
<head>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
        <link rel="icon" href="<?php echo e(asset('app/icons/favicon.ico')); ?>">
        <meta name="theme-color" content="#8CC152">
        <meta name="viewport"
            content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
        <title>Absensi Online | Login Admin</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/bootstrap.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/style.css')); ?>">
        <link
            href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i|Source+Sans+Pro:300,300i,400,400i,600,600i,700,700i,900,900i&display=swap"
            rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/css/fontawesome-all.min.css')); ?>">
        <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>" data-pwa-version="set_in_manifest_and_pwa_js">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('app/icons/icon-192x192.png')); ?>">
    </head>

<body class="theme-light" data-highlight="highlight-red" data-gradient="body-default">

<div id="preloader"><div class="spinner-border color-highlight" role="status"></div></div>

<div id="page">

    <div class="page-content pb-0">

        <div data-card-height="cover" class="card">
            
            <div class="card-center">
                <div class="ps-5 pe-5">
                    <img class="text-center rounded mx-auto d-block mt-5" src="<?php echo e(asset('images/preload-logo.png')); ?>" width="90">
                    <h1 class="text-center font-800 font-40 mb-1">Login</h1>
                    <p class="color-highlight text-center font-12">Halaman Admin Absensi Online DKP3A</p>
                    <form method="POST" action="<?php echo e(route('login.custom')); ?>">
                        <?php echo csrf_field(); ?>
                    <div class="input-style no-borders has-icon validate-field">
                        <i class="fa fa-user"></i>
                        <input type="email" name="email" class="form-control validate-name" id="form1a" placeholder="NIP/ID" value="<?php echo e(old('email')); ?>" required>
                        <label for="form1a" class="color-blue-dark font-10 mt-1">NIP/ID</label>
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                    </div>

                    <div class="input-style no-borders has-icon validate-field mt-4">
                        <i class="fa fa-lock"></i>
                        <input type="password" name="password" class="form-control validate-password" id="form3a" placeholder="Password" required>
                        <label for="form3a" class="color-blue-dark font-10 mt-1">Password</label>
                        <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                    </div>

                    <a href="#" onclick="parentNode.submit();" class="back-button btn btn-full btn-m shadow-large rounded-sm text-uppercase font-700 bg-highlight">LOGIN</a>
                    <div class="divider mt-4"></div>
                </form>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- End of Page Content-->
</div>

    <script type="text/javascript" src="<?php echo e(asset('scripts/bootstrap.min.js')); ?>"></script>    
    <script type="text/javascript" src="<?php echo e(asset('scripts/custom.js')); ?>"></script>
</body>
<?php /**PATH C:\xampp\htdocs\absensi-online\resources\views/login.blade.php ENDPATH**/ ?>