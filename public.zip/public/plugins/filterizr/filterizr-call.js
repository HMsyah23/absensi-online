var galleryFilterOptions = {};
var filterizr = new Filterizr('.gallery-filter', galleryFilterOptions);